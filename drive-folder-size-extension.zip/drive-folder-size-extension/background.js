chrome.action.onClicked.addListener(async (tab)=>{

  try {


    if (!tab.id) return;


    if (!tab.url) return;


    if (
      tab.url.startsWith("chrome://") ||
      tab.url.startsWith("edge://") ||
      tab.url.startsWith("about:") ||
      tab.url.startsWith("chrome-extension://")
    ) {
      console.log("Blocked page:", tab.url);
      return;
    }


    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["inject.js"]
    });

  } catch (err) {

    console.log("Injection blocked:", err.message);
  }

});