
(async function(){


let existing = document.getElementById("dfs-popup");
if(existing){
  existing.remove();
  return;
}


let popup=document.createElement("div");
popup.id = "dfs-popup"; 

popup.innerHTML=`
<div style="position:fixed;top:20px;right:20px;background:#f9fafb;padding:20px;border-radius:16px;width:360px;font-family:sans-serif;box-shadow:0 15px 30px rgba(0,0,0,0.2);z-index:999999">

<span id="close" style="position:absolute;top:10px;right:12px;cursor:pointer;">✖</span>

<h3>📦 GDrive Folder Size <span style="background:#E5E3FB;padding:4px 10px;border-radius:999px;font-size:12px;">V1.0 | Beta</span></h3>

<p id="result" style="font-size:30px;font-weight:700;color:#4f46e5;">Loading...</p>
 <p style="font-size:12px;color:#dc2626;margin:0 0 10px 0;"><b>
        Please close this popup and reopen it after switching folders.<br>If you are in the root directory, only the file size will be shown, not the full drive size.</b>
      </p>


 <hr>

      <h4 style="margin:8px 0;">Enjoying this tool? Consider supporting us 🚀</h4>
      <div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:8px;">
        <a href="https://www.supportkori.com/mazbah229" target="_blank">
          <img src="${chrome.runtime.getURL('supportkori.png')}" style="height:34px;">
        </a>
        <a href="https://www.buymeacoffee.com/mazbah229" target="_blank">
          <img src="${chrome.runtime.getURL('bmc.png')}" style="height:34px;">
        </a>
        <a href="https://pixonexit.com/bank-details" target="_blank">
          <img src="${chrome.runtime.getURL('bank.png')}" style="height:34px;">
        </a>
 <a href="https://pixonexit.com/bank-details/#MFS" target="_blank">
          <img src="${chrome.runtime.getURL('dbd.png')}" style="height:34px;">
        </a>

      </div>

      <hr>
<div id="loginBox" style="display:none;text-align:center;margin-top:10px;">
<h3><b>🔐 Please login to continue</b></h3>
<a id="loginBtn" 
style="display:flex;align-items:center;justify-content:center;gap:8px;width:100%;padding:8px;background:#4f46e5;color:#fff;text-decoration:none;font-size:14px;font-weight:600;border-radius:8px;">
  <!-- SVG Icon -->
  <svg xmlns="http://www.w3.org/2000/svg" 
       viewBox="0 0 640 640"
       style="width:16px;height:16px;fill:#ffffff;flex-shrink:0;">
    <path d="M564 325.8C564 467.3 467.1 568 324 568C186.8 568 76 457.2 76 320C76 182.8 186.8 72 324 72C390.8 72 447 96.5 490.3 136.9L422.8 201.8C334.5 116.6 170.3 180.6 170.3 320C170.3 406.5 239.4 476.6 324 476.6C422.2 476.6 459 406.2 464.8 369.7L324 369.7L324 284.4L560.1 284.4C562.4 297.1 564 309.3 564 325.8z"/>
  </svg>

  Login with Google
</a>
</div>
    <a href="https://cext-auth.pixonexit.com/user.html" target="_blank"
   style="display:inline-flex;
   align-items:center;
   justify-content:center;
   gap:8px;
   width:100%;
   padding:8px;
   background:#0ea5e9;
   color:#fff;
   border:none;
   border-radius:8px;
   margin:10px 0;
   text-align:center;
   text-decoration:none;
   font-size:14px;">

   <!-- SVG Icon -->
   <svg xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 640 640"
        style="width:16px;height:16px;fill:#ffffff;flex-shrink:0;">
     <path d="M566.6 214.6L470.6 310.6C458.1 323.1 437.8 323.1 425.3 310.6C412.8 298.1 412.8 277.8 425.3 265.3L466.7 224L96 224C78.3 224 64 209.7 64 192C64 174.3 78.3 160 96 160L466.7 160L425.3 118.6C412.8 106.1 412.8 85.8 425.3 73.3C437.8 60.8 458.1 60.8 470.6 73.3L566.6 169.3C579.1 181.8 579.1 202.1 566.6 214.6zM169.3 566.6L73.3 470.6C60.8 458.1 60.8 437.8 73.3 425.3L169.3 329.3C181.8 316.8 202.1 316.8 214.6 329.3C227.1 341.8 227.1 362.1 214.6 374.6L173.3 416L544 416C561.7 416 576 430.3 576 448C576 465.7 561.7 480 544 480L173.3 480L214.7 521.4C227.2 533.9 227.2 554.2 214.7 566.7C202.2 579.2 181.9 579.2 169.4 566.7z"/>
   </svg>

   <b>Switch Account</b>
</a>

      <a href="https://pixonexit.com/extensions/gdrive-folder-size/new-version/" target="_blank" 
      style="display:flex;align-items:center;justify-content:center;gap:8px;width:100%;padding:8px;background:#4f46e5;color:#fff;text-decoration:none;font-size:14px;font-weight:600;border-radius:8px;">
       <svg xmlns="http://www.w3.org/2000/svg" 
       viewBox="0 0 640 640"
       style="width:16px;height:16px;fill:#ffffff;flex-shrink:0;">
    <path d="M129.9 292.5C143.2 199.5 223.3 128 320 128C373 128 421 149.5 455.8 184.2C456 184.4 456.2 184.6 456.4 184.8L464 192L416.1 192C398.4 192 384.1 206.3 384.1 224C384.1 241.7 398.4 256 416.1 256L544.1 256C561.8 256 576.1 241.7 576.1 224L576.1 96C576.1 78.3 561.8 64 544.1 64C526.4 64 512.1 78.3 512.1 96L512.1 149.4L500.8 138.7C454.5 92.6 390.5 64 320 64C191 64 84.3 159.4 66.6 283.5C64.1 301 76.2 317.2 93.7 319.7C111.2 322.2 127.4 310 129.9 292.6zM573.4 356.5C575.9 339 563.7 322.8 546.3 320.3C528.9 317.8 512.6 330 510.1 347.4C496.8 440.4 416.7 511.9 320 511.9C267 511.9 219 490.4 184.2 455.7C184 455.5 183.8 455.3 183.6 455.1L176 447.9L223.9 447.9C241.6 447.9 255.9 433.6 255.9 415.9C255.9 398.2 241.6 383.9 223.9 383.9L96 384C87.5 384 79.3 387.4 73.3 393.5C67.3 399.6 63.9 407.7 64 416.3L65 543.3C65.1 561 79.6 575.2 97.3 575C115 574.8 129.2 560.4 129 542.7L128.6 491.2L139.3 501.3C185.6 547.4 249.5 576 320 576C449 576 555.7 480.6 573.4 356.5z"/>
  </svg> Check For New Version
      </a>

      <hr>

      <h3 style="font-size:12px;display:flex;align-items:center;justify-content:center;gap:6px;margin-top:10px;text-align:center;">
        GDrive Folder Size Extension | Developed By
        <a href="https://pixonexit.com" target="_blank" style="display:flex;align-items:center;">
          <img src="${chrome.runtime.getURL('logo.png')}" style="height:18px;">
        </a>
      </h3>

</div>

`;

document.body.appendChild(popup);


document.getElementById("close").onclick=()=>popup.remove();


setTimeout(()=>{
  document.addEventListener("click", function(e){
    const box = document.getElementById("dfs-box");
    if(box && !box.contains(e.target)){
      const popup = document.getElementById("dfs-popup");
      if(popup) popup.remove();
    }
  });
}, 100);



const result=document.getElementById("result");
const loginBox=document.getElementById("loginBox");

function formatSize(b){
 if(b<1024) return b+" B";
 if(b<1024*1024) return (b/1024).toFixed(2)+" KB";
 if(b<1024*1024*1024) return (b/1024/1024).toFixed(2)+" MB";
 return (b/1024/1024/1024).toFixed(2)+" GB";
}

function showLogin(){
 result.textContent="";
 loginBox.style.display="block";
}

async function calculate(token){

 result.textContent="Calculating...";

 async function getSize(id){
  let total=0,pageToken=null;
  do{
   let url=`https://www.googleapis.com/drive/v3/files?q='${id}'+in+parents&fields=nextPageToken,files(id,size,mimeType)&pageSize=1000`;
   if(pageToken) url+="&pageToken="+pageToken;

   const r=await fetch(url,{headers:{Authorization:"Bearer "+token}});
   const d=await r.json();

   for(const f of (d.files||[])){
    if(f.mimeType==="application/vnd.google-apps.folder"){
      total+=await getSize(f.id);
    } else {
      total+=parseInt(f.size||0);
    }
   }

   pageToken=d.nextPageToken;
  }while(pageToken);

  return total;
 }

 const m=location.href.match(/folders\/([^/?]+)/);
 const id = m ? m[1] : "root";

 const size=await getSize(id);
 result.textContent=formatSize(size);
}

chrome.storage.local.get("token",(data)=>{
 if(!data.token){
   showLogin();
 }else{


   if(!location.hostname.includes("drive.google.com")){
     
     result.innerHTML = `
     <div style="text-align:center;">

   <p style="font-size:16px;font-weight:600;color:red;display:flex;align-items:center;gap:6px;">
  
  <!-- Google Drive Icon (Font Awesome SVG) -->
  <svg xmlns="http://www.w3.org/2000/svg" 
       viewBox="0 0 640 640" 
       width="18" 
       height="18" 
       fill="currentColor">
    <path d="M403 378.9L239.4 96L400.6 96L564.2 378.9L403 378.9zM265.5 402.5L184.9 544L495.4 544L576 402.5L265.5 402.5zM218.1 131.4L64 402.5L144.6 544L301 272.8L218.1 131.4z"/>
  </svg>

  Open Google Drive First.
</p>
           </div>
     `;

     return;
   }


   calculate(data.token);
 }
});

document.getElementById("loginBtn").onclick=()=>{
 window.open("https://cext-auth.pixonexit.com/login.html","_blank");
};

window.addEventListener("message",(event)=>{
 if(event.data && event.data.token){
   chrome.storage.local.set({token:event.data.token},()=>{
     document.getElementById("result").textContent = "Login successful! Refreshing...";
     setTimeout(()=>{
       window.location.reload();
     }, 800);
   });
 }
});

})();